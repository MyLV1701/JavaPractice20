# sitepoint-serialized-java-phone-book
Source code for my tutorial on serializing Java objects. 
